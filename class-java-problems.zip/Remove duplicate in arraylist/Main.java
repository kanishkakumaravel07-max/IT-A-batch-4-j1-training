import java.util.ArrayList;
public class Main {
    public static void main(String[] args) {
        ArrayList<Integer> a = new ArrayList<>();
        a.add(1);
        a.add(2);
        a.add(3);
        a.add(2);
        a.add(4);
        a.add(5);
        for(int i = 1;i<a.size();i++){
            for(int j = i+1;j<a.size();j++){
                if(a.get(i).equals(a.get(j))){
                    a.remove(j);
                    j--;
                }
            }
        }
	 System.out.println(a);
    }
}  