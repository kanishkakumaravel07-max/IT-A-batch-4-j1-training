import java.util.ArrayList;
public class Main {
    public static void main(String[] args) {
        ArrayList<Integer> a = new ArrayList<>();
        a.add(1);
        a.add(2);
        a.add(3);
        a.add(2);
        a.add(4);
        a.add(5);
        for(int i = a.size()-1;i>=0;i--){
            System.out.println(a.get(i));
        }
	 
    }
}  