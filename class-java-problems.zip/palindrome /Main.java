import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = "madam";
        String rev = "";
        for(int i = str.length() - 1; i>=0;--i){
            rev+=str.charAt(i);
        }
        
        System.out.println(rev);
        if(str.equals(rev)){
            System.out.println("It is palindrome");
        } else{
            System.out.println("It is not palindrome");
        }
    
  }
} 