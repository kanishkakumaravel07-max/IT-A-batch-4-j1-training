import java.util.ArrayList;
import java.util.Collections;

class Main {
    public static void main (String[] args) {
        
      	
      	ArrayList<Integer> a = new ArrayList<>();
      	a.add(1);
      	a.add(2);
      	a.add(3);
      	a.add(4);
      	a.add(10);
        a.add(5);
        a.add(9);
        a.add(8);
        a.add(6);
        a.add(7);
        Collections.sort(a);
        int large = a.get(a.size() - 2);
               	System.out.println(large); 
            }
            
           
        }
       
        
      
      //	System.out.println(a);
      //	System.out.println(a.contains("A"));
     

/*System.out.println(a.size());
        int smaller = 0;
        int greater = 0;
        for(int i = 0;i<10;i++){
             a.get(i);
            if(i<10){
               	System.out.println(a); 
            }
            
           
        }*/
