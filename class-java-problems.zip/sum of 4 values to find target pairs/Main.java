import java.util.*;
public class Main{
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] a = new int[n];
        int target = sc.nextInt();
        for(int i=0;i<n;i++){
            a[i] = sc.nextInt();
        }
        for(int i=0;i<n;i++){
            for(int j = i+1; j < n; j++){
                for(int k=j+1;k<n;k++){
                    for(int z=k+1;k<n;k++){
                         if(a[i]+a[j]+a[k]+a[z]==target){
                    System.out.println(a[i] + " " + a[j] + " "  + a[k] + " " + a[z]);
                }
                    }
            }
            }
            }
        }
         
    }