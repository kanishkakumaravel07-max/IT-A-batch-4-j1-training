/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int n = 5;
	    for(int i = n;i>=1;i--){
	        for(int j = n;j>=n-i+1;j--){
	            System.out.print((char)('A'+ j-1));
	        }
	        System.out.println( );
	    }
		
	}
}