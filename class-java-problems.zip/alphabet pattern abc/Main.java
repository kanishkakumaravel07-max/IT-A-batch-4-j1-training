import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int n = sc.nextInt();
	    
	    char ch = 'E';
	    
	    for(int i = n ;i>=1;i--){
	        for(int j = 1;j<=i;j++){
	            if(ch>='A' && ch <='E'){
	            System.out.print(ch + " ");
	        }
	        }
	        ch--;
	        System.out.println( );     
	    }
		
	}
}   
/*
E E E E E
D D D D
C C C
B B
A */