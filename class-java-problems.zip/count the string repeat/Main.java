





import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc. nextLine();

        char[] ch = str.toCharArray();

        for(int i = 0; i < ch.length; i++) {

            int count = 1;

            if(ch[i] == '1')
                continue;   

            for(int j = i + 1; j < ch.length; j++) {
                if(ch[i] == ch[j]) {
                    count++;
                    ch[j] = '1';
                }
            }

            System.out.println(ch[i] + " = " + count);
        }
    }
}