import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    String s = sc.nextLine();
	    for(int i = 0;i<s.length();i++){
	        char ch = s.charAt(i);
	        if(!(ch >= 'a' &&ch <= 'z') && !(ch >= '0' &&ch <='9') && !(ch >='A'  && ch <= 'Z')){
	            System.out.print(s.charAt(i));
	        }
	    }
		
	}
}