import java.util.*;

public class Main {

    static void dfs(int[][] a, int i, int j, int m, int n) {
        if (i < 0 || i >= m || j < 0 || j >= n || a[i][j] == 0)
            return;

        a[i][j] = 0;

        dfs(a, i + 1, j, m, n);
        dfs(a, i - 1, j, m, n);
        dfs(a, i, j + 1, m, n);
        dfs(a, i, j - 1, m, n);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int m = sc.nextInt();
        int n = sc.nextInt();

        int[][] a = new int[m][n];

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = sc.nextInt();
            }
        }

        int count = 0;

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (a[i][j] == 1) {
                    dfs(a, i, j, m, n);
                    count++;
                }
            }
        }

        System.out.println(count);
    }
}
