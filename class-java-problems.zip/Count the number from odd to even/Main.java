import java.util.*;
public class Main{
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int[] s = new int[a];
        int count = 0;
        for(int i=0;i<a;i++){
            s[i]=sc.nextInt();
            if(s[i]%2!=0 && s[i+1]%2==0){
                count++;
            }
        }
         System.out.print(count);
    }
}
